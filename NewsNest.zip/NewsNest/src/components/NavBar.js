import React, { Component } from 'react';
import { Link } from 'react-router-dom';

export class NavBar extends Component {
  state = {
    isMenuOpen: false
  };

  toggleMenu = () => {
    this.setState(prevState => ({
      isMenuOpen: !prevState.isMenuOpen
    }));
  }; 

  closeMenu = () => {
    this.setState({ isMenuOpen: false });
  };

  render() {
    const { isMenuOpen } = this.state;

    return (
      <header className="navbar">
        <Link className="navbar-brand" to="/" onClick={this.closeMenu}>
          News<span>Nest</span>
        </Link>
        <div className="navbar-container">
          <button className={`menu-toggle ${isMenuOpen ? 'open' : ''}`} onClick={this.toggleMenu}>
            <span className="bar"></span>
            <span className="bar"></span>
            <span className="bar"></span>
          </button>
          <nav className={`nav-menu ${isMenuOpen ? 'active' : ''}`}>
            <ul>
              <li><Link to="/" onClick={this.closeMenu}>Home</Link></li>
              <li><Link to="/business" onClick={this.closeMenu}>Business</Link></li>
              <li><Link to="/entertainment" onClick={this.closeMenu}>Entertainment</Link></li>
              <li><Link to="/health" onClick={this.closeMenu}>Health</Link></li>
              <li><Link to="/science" onClick={this.closeMenu}>Science</Link></li>
              <li><Link to="/sports" onClick={this.closeMenu}>Sports</Link></li>
              <li><Link to="/technology" onClick={this.closeMenu}>Technology</Link></li>
            </ul>
          </nav>
        </div>
      </header>
    );
  }
}

export default NavBar;
