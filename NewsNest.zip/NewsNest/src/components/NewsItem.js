import React, { Component } from 'react'

export class NewsItem extends Component {
  render() {
    let {title, description, imageUrl, newsUrl, author, date, source, badge} = this.props;
    return (

      <div className='my-3 position-relative'>
        <span className={`badge rounded-pill text-bg-${badge} position-absolute `} style={{zIndex:'1', right:'0%', top:'-8px'}}>{source}</span>
        <div className="card my-3">
            <img src={imageUrl} className="card-img-top" alt="pic"/>
            <div className="card-body">
                <h5 className="card-title">{title}</h5>
                <p className="card-text">{description}</p>
                <p className="card-text"><small>By {author} On {new Date(date).toGMTString()}</small></p>
                <a href={newsUrl} rel='noreferrer'  target="_blank" className="btn btn-dark btn-sm">Read more</a>
            </div>
            </div>
      </div>
    )
    }
}

export default NewsItem;
